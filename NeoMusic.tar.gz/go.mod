module builder

go 1.26.2

require github.com/dhowden/tag v0.0.0-20240417053706-3d75831295e8 // indirect
