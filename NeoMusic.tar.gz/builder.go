package main

import (
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/dhowden/tag"
)

type Song struct {
	ID       string `json:"id"`
	Title    string `json:"title"`
	Artist   string `json:"artist"`
	Album    string `json:"album"`
	Lyrics   string `json:"lyrics"`
	AudioURL string `json:"audio_url"`
	ArtURL   string `json:"art_url"`
}

type Config struct {
	Binding  string `json:"binding"`
	Port     string `json:"port"`
	MusicDir string `json:"music_dir"`
}

var songsList []Song
var artDir = "./tmp_art"
var serverConfig Config
var configPath = "config.json"

var favoritesPath = "favorites.json"
var favoriteIDs []string

var songsCachePath = "songs_cache.json"

var manifestPath = "manifest.json"
var swPath = "service-worker.js"

// Map to track unique songs based on metadata + size to prevent symlink overlap duplicates
var seenSongIDs map[string]bool

func loadConfig() {
	file, err := os.ReadFile(configPath)
	if err != nil {
		serverConfig = Config{
			Binding:  "0.0.0.0",
			Port:     "1220",
			MusicDir: "/data/data/com.termux/files/home/storage",
		}
		saveConfig()
	} else {
		json.Unmarshal(file, &serverConfig)
		// Fallback in case MusicDir is missing from an old config
		if serverConfig.MusicDir == "" {
			serverConfig.MusicDir = "/data/data/com.termux/files/home/storage"
			saveConfig()
		}
	}
}

func saveConfig() {
	data, _ := json.MarshalIndent(serverConfig, "", "  ")
	os.WriteFile(configPath, data, 0644)
}

func loadFavorites() {
	file, err := os.ReadFile(favoritesPath)
	if err == nil {
		json.Unmarshal(file, &favoriteIDs)
	} else {
		favoriteIDs = []string{}
	}
}

func saveFavorites() {
	data, _ := json.MarshalIndent(favoriteIDs, "", "  ")
	os.WriteFile(favoritesPath, data, 0644)
}

func loadSongsCache() bool {
	file, err := os.ReadFile(songsCachePath)
	if err == nil {
		err = json.Unmarshal(file, &songsList)
		if err == nil && len(songsList) > 0 {
			return true
		}
	}
	return false
}

func saveSongsCache() {
	data, _ := json.MarshalIndent(songsList, "", "  ")
	os.WriteFile(songsCachePath, data, 0644)
}

func initPWA() {
	// Create manifest.json if it doesn't exist
	if _, err := os.Stat(manifestPath); os.IsNotExist(err) {
		manifestContent := `{
    "name": "NeoMusic",
    "short_name": "NeoMusic",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#121212",
    "theme_color": "#2979ff",
    "icons": [
        {
            "src": "/icon.png",
            "sizes": "512x512",
            "type": "image/png",
            "purpose": "any maskable"
        }
    ]
}`
		os.WriteFile(manifestPath, []byte(manifestContent), 0644)
		fmt.Println("Created default manifest.json")
	}

	// Create service-worker.js if it doesn't exist
	if _, err := os.Stat(swPath); os.IsNotExist(err) {
		os.WriteFile(swPath, swCode, 0644)
		fmt.Println("Created default service-worker.js")
	}
}

func main() {
	loadConfig()
	loadFavorites()
	initPWA()

	// Ensure temp art directory exists
	os.MkdirAll(artDir, os.ModePerm)

	// Prevent Android Gallery from indexing the album arts
	os.WriteFile(filepath.Join(artDir, ".nomedia"), []byte(""), 0644)

	// Check for cached songs to avoid scanning every startup
	if loadSongsCache() {
		fmt.Printf("Loaded %d songs from cache. Skipping full scan.\n", len(songsList))
	} else {
		fmt.Println("First run or cache missing. Scanning music files recursively in:", serverConfig.MusicDir, "...")
		scanMusic()
	}

	http.HandleFunc("/api/songs", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Access-Control-Allow-Origin", "*")
		json.NewEncoder(w).Encode(songsList)
	})

	http.HandleFunc("/api/favorites", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Access-Control-Allow-Origin", "*")

		if r.Method == "GET" {
			json.NewEncoder(w).Encode(favoriteIDs)
			return
		}

		if r.Method == "POST" {
			var newFavs []string
			if err := json.NewDecoder(r.Body).Decode(&newFavs); err == nil {
				favoriteIDs = newFavs
				saveFavorites()
				w.WriteHeader(http.StatusOK)
				w.Write([]byte(`{"status":"success"}`))
			} else {
				w.WriteHeader(http.StatusBadRequest)
			}
		}
	})

	http.HandleFunc("/api/rescan", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		scanMusic()
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"status":"success"}`))
	})

	http.HandleFunc("/api/config", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Access-Control-Allow-Origin", "*")

		if r.Method == "GET" {
			json.NewEncoder(w).Encode(serverConfig)
			return
		}

		if r.Method == "POST" {
			var newConfig Config
			if err := json.NewDecoder(r.Body).Decode(&newConfig); err == nil {
				oldDir := serverConfig.MusicDir
				serverConfig = newConfig
				saveConfig()

				if oldDir != serverConfig.MusicDir {
					scanMusic()
				}

				w.WriteHeader(http.StatusOK)
				w.Write([]byte(`{"status":"success"}`))
			} else {
				w.WriteHeader(http.StatusBadRequest)
			}
		}
	})

	http.HandleFunc("/music/", func(w http.ResponseWriter, r *http.Request) {
		http.StripPrefix("/music/", http.FileServer(http.Dir(serverConfig.MusicDir))).ServeHTTP(w, r)
	})
	
	http.Handle("/art/", http.StripPrefix("/art/", http.FileServer(http.Dir(artDir))))

	http.HandleFunc("/icon.png", func(w http.ResponseWriter, r *http.Request) {
		http.ServeFile(w, r, "icon.png")
	})

	// Serve generated PWA files from disk
	http.HandleFunc("/manifest.json", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		http.ServeFile(w, r, manifestPath)
	})

	http.HandleFunc("/service-worker.js", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/javascript")
		http.ServeFile(w, r, swPath)
	})

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		w.Write(indexHtmlCode)
	})

	addr := fmt.Sprintf("%s:%s", serverConfig.Binding, serverConfig.Port)

	fmt.Println("======================================")
	fmt.Println(" NeoMusic Server Successfully Started")
	fmt.Printf(" Open your browser to: http://localhost:%s\n", serverConfig.Port)
	fmt.Println(" Press Ctrl+C to stop.")
	fmt.Println("======================================")

	log.Fatal(http.ListenAndServe(addr, nil))
}

func scanMusic() {
	songsList = []Song{}
	seenSongIDs = make(map[string]bool)
	walkAndScan(serverConfig.MusicDir)
	saveSongsCache()
	fmt.Printf("Scanned %d songs successfully and updated cache.\n", len(songsList))
}

func isAudioFile(filename string) bool {
	ext := strings.ToLower(filepath.Ext(filename))
	return ext == ".mp3" || ext == ".flac" || ext == ".m4a" || ext == ".ogg" || ext == ".wav"
}

func walkAndScan(dir string) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}

	for _, entry := range entries {
		path := filepath.Join(dir, entry.Name())
		info, err := os.Stat(path)
		if err != nil {
			continue
		}

		if info.IsDir() {
			if strings.HasPrefix(info.Name(), ".") {
				continue
			}
			walkAndScan(path)
		} else if isAudioFile(info.Name()) {
			processFile(path, info)
		}
	}
}

func processFile(path string, info os.FileInfo) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()

	m, err := tag.ReadFrom(f)
	if err != nil {
		// Suppressed log
	}

	title := ""
	artist := "Unknown Artist"
	album := "Unknown Album"
	lyrics := ""
	artURL := ""
	
	var picData []byte
	picExt := "jpg"

	if m != nil {
		title = m.Title()
		artist = m.Artist()
		album = m.Album()
		lyrics = m.Lyrics()

		if m.Picture() != nil {
			pic := m.Picture()
			picData = pic.Data
			if pic.MIMEType == "image/png" {
				picExt = "png"
			}
		}
	}

	if title == "" {
		title = info.Name()
	}

	uniqueKey := fmt.Sprintf("%s|%s|%s|%d", title, artist, album, info.Size())
	hash := md5.Sum([]byte(uniqueKey))
	id := hex.EncodeToString(hash[:])

	if seenSongIDs[id] {
		return
	}
	seenSongIDs[id] = true

	if picData != nil {
		artFilename := fmt.Sprintf("%s.%s", id, picExt)
		artPath := filepath.Join(artDir, artFilename)

		if _, err := os.Stat(artPath); os.IsNotExist(err) {
			os.WriteFile(artPath, picData, 0644)
		}
		artURL = "/art/" + artFilename
	}

	relPath, err := filepath.Rel(serverConfig.MusicDir, path)
	if err != nil {
		return
	}

	song := Song{
		ID:       id,
		Title:    title,
		Artist:   artist,
		Album:    album,
		Lyrics:   lyrics,
		AudioURL: "/music/" + filepath.ToSlash(relPath),
		ArtURL:   artURL,
	}
	songsList = append(songsList, song)
}

// Service worker logic embedded as a byte array
var swCode = []byte(`const CACHE_NAME = 'neomusic-v1';
const STATIC_ASSETS = ['/', '/manifest.json', '/icon.png'];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
    );
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then(keys => Promise.all(
            keys.map(key => {
                if (key !== CACHE_NAME) return caches.delete(key);
            })
        ))
    );
    self.clients.claim();
});

self.addEventListener('fetch', (event) => {
    if (event.request.method !== 'GET') return;

    const url = new URL(event.request.url);

    // API endpoints (Network First, fallback to cache)
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(
            fetch(event.request)
                .then(res => {
                    const resClone = res.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(event.request, resClone));
                    return res;
                })
                .catch(() => caches.match(event.request))
        );
        return;
    }

    // Media and Art (Cache First if downloaded, else Network)
    if (url.pathname.startsWith('/music/') || url.pathname.startsWith('/art/')) {
        event.respondWith(
            caches.match(event.request).then(cachedRes => {
                if (cachedRes) return cachedRes; // Play from offline cache immediately

                return fetch(event.request).then(networkRes => {
                    // Automatically cache album art to save network
                    if (url.pathname.startsWith('/art/')) {
                        const resClone = networkRes.clone();
                        caches.open(CACHE_NAME).then(cache => cache.put(event.request, resClone));
                    }
                    return networkRes;
                });
            })
        );
        return;
    }

    // Default (HTML, CSS, JS): Stale-While-Revalidate
    event.respondWith(
        caches.match(event.request).then(cachedRes => {
            const fetchPromise = fetch(event.request).then(networkRes => {
                caches.open(CACHE_NAME).then(cache => cache.put(event.request, networkRes.clone()));
                return networkRes;
            }).catch(() => {});
            return cachedRes || fetchPromise;
        })
    );
});
`)

var indexHtmlCode = []byte(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>NeoMusic</title>
    <link rel="icon" href="/icon.png" type="image/png">
    <link rel="apple-touch-icon" href="/icon.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#121212">
    <style>
        :root {
            --bg-base: #121212;
            --bg-surface: rgba(24, 24, 24, 0.6); 
            --bg-elevated: rgba(40, 40, 40, 0.7);
            --text-primary: #ffffff;
            --text-secondary: #e0e0e0;
            --accent: #2979ff;       
            --accent-hover: #448aff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: 'Circular', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg-base);
            color: var(--text-primary);
            display: flex;
            justify-content: center;
            min-height: 100vh;
            min-height: -webkit-fill-available;
            padding: 20px;
            padding-bottom: max(20px, env(safe-area-inset-bottom));
            padding-top: max(20px, env(safe-area-inset-top));
            position: relative;
        }

        /* DYNAMIC BLURRED BACKGROUND */
        .bg-blur {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            width: 100%; height: 100%;
            z-index: -1;
            background-size: cover;
            background-position: center;
            filter: blur(25px) brightness(0.35);
            transform: scale(1.1); 
            transition: background-image 0.5s ease-in-out;
        }

        .app-container {
            width: 100%;
            max-width: 450px; 
            display: flex;
            flex-direction: column;
            height: 100%;
            transition: max-width 0.3s ease;
            z-index: 1;
        }

        .top-bar {
            position: relative;
            display: flex;
            gap: 8px;
            margin-bottom: 25px;
            z-index: 100;
            width: 100%;
        }

        .search-container {
            position: relative;
            flex-grow: 1;
        }

        .search-bar {
            width: 100%;
            height: 44px;
            padding: 0 20px 0 45px;
            border-radius: 500px;
            border: none;
            background-color: var(--bg-elevated);
            backdrop-filter: blur(10px);
            color: var(--text-primary);
            font-size: 0.95rem;
            outline: none;
            transition: background-color 0.2s;
        }

        .search-bar:focus, .search-bar:hover { background-color: rgba(60, 60, 60, 0.8); }

        .search-icon-svg {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            width: 18px;
            height: 18px;
        }

        .library-btn {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background-color: var(--bg-elevated);
            backdrop-filter: blur(10px);
            border: none;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            flex-shrink: 0;
        }

        .library-btn:hover {
            background-color: rgba(60, 60, 60, 0.8);
        }

        .library-btn svg { width: 20px; height: 20px; stroke: currentColor; }
        
        .playlist-active { color: var(--accent); }

        .list-dropdown {
            position: absolute;
            top: 54px; 
            left: 0;
            width: 100%;
            max-height: 280px;
            overflow-y: auto;
            background-color: rgba(30, 30, 30, 0.95);
            backdrop-filter: blur(15px);
            border-radius: 8px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.6);
            display: none;
            list-style: none;
            padding: 8px 0;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,0.2) transparent;
        }

        .list-dropdown::-webkit-scrollbar { width: 6px; }
        .list-dropdown::-webkit-scrollbar-thumb { background-color: rgba(255,255,255,0.2); border-radius: 10px; }

        .list-dropdown li {
            padding: 10px 20px;
            cursor: pointer;
            color: var(--text-secondary);
            font-size: 0.9rem;
            display: flex;
            flex-direction: column;
            border-left: 3px solid transparent;
        }

        .list-dropdown li span.res-title { 
            color: var(--text-primary); 
            font-weight: 500; 
            margin-bottom: 2px; 
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .list-dropdown li span.res-artist {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .list-dropdown li:hover { background-color: rgba(255,255,255,0.1); }
        .list-dropdown li.active-song { border-left-color: var(--accent); background-color: rgba(41, 121, 255, 0.2); }
        .list-dropdown li.active-song span.res-title { color: var(--accent); }

        .player-content {
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }

        .player-left {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .player-right {
            width: 100%;
            display: flex;
            flex-direction: column;
            min-width: 0;
        }

        .art-container {
            width: 450px;
            height: 450px;
            max-width: 100%;
            aspect-ratio: 1/1;
            flex-shrink: 0; 
            border-radius: 12px;
            background-color: rgba(0, 0, 0, 0.4);
            box-shadow: 0 15px 35px rgba(0,0,0,0.5);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23b3b3b3' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M9 18V5l12-2v13'%3E%3C/path%3E%3Ccircle cx='6' cy='18' r='3'%3E%3C/circle%3E%3Ccircle cx='18' cy='16' r='3'%3E%3C/circle%3E%3C/svg%3E");
            background-size: 60px;
            background-position: center;
            background-repeat: no-repeat;
        }

        .art-container img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
            z-index: 5;
            transition: opacity 0.3s ease;
        }

        .lyrics-container {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(10, 10, 10, 0.85);
            backdrop-filter: blur(10px);
            padding: 20px;
            overflow-y: auto;
            text-align: center;
            line-height: 1.8;
            font-size: 0.95rem;
            color: var(--text-primary);
            display: none; 
            z-index: 10;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,0.2) transparent;
        }

        .lyrics-container::-webkit-scrollbar { width: 6px; }
        .lyrics-container::-webkit-scrollbar-thumb { background-color: rgba(255,255,255,0.2); border-radius: 10px; }

        .art-container.show-lyrics .lyrics-container { display: block; }

        /* HEART & DOWNLOAD BUTTONS */
        #heartBtn, #downloadBtn {
            position: absolute;
            bottom: 15px;
            z-index: 20;
            background: rgba(18, 18, 18, 0.6);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.1s, background-color 0.2s, color 0.2s;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0,0,0,0.4);
        }

        #heartBtn { right: 15px; }
        #downloadBtn { left: 15px; }

        #heartBtn:hover, #downloadBtn:hover { 
            background: rgba(40, 40, 40, 0.8); 
            transform: scale(1.05);
        }

        #heartBtn:active, #downloadBtn:active { transform: scale(0.95); }
        #heartBtn svg, #downloadBtn svg { width: 22px; height: 22px; fill: none; stroke: currentColor; stroke-width: 2; }

        #heartEmpty { fill: transparent !important; }
        #heartFilled { display: none; }
        #heartBtn.heart-active { color: var(--accent); }
        #heartBtn.heart-active #heartEmpty { display: none; }
        #heartBtn.heart-active #heartFilled { display: block; fill: currentColor; }

        #downloadBtn.downloaded { color: #4caf50; }

        .info-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
            width: 100%;
            min-width: 0;
        }

        .title {
            width: 100%;
            text-align: center;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            text-shadow: 0 2px 4px rgba(0,0,0,0.5);
        }

        .artist {
            width: 100%;
            text-align: center;
            font-size: 1.1rem;
            color: var(--text-secondary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            text-shadow: 0 1px 3px rgba(0,0,0,0.5);
        }

        .lyrics-toggle {
            background: transparent;
            border: 1px solid rgba(255,255,255,0.3);
            color: var(--text-primary);
            border-radius: 20px;
            padding: 5px 16px;
            font-size: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 15px;
            backdrop-filter: blur(5px);
        }

        .lyrics-toggle:hover { 
            border-color: var(--text-primary);
            background-color: rgba(255,255,255,0.1);
        }

        .lyrics-toggle.active { 
            background: var(--text-primary); 
            color: #121212; 
            border-color: var(--text-primary); 
        }

        .progress-wrapper {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
            width: 100%;
        }

        .visualizer-container {
            position: relative;
            width: 100%;
            height: 50px;
            cursor: pointer;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }

        .visualizer-container canvas {
            width: 100%;
            height: 100%;
            z-index: 10;
        }

        .time-labels {
            display: flex;
            justify-content: space-between;
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-secondary);
            font-variant-numeric: tabular-nums;
            text-shadow: 0 1px 2px rgba(0,0,0,0.5);
        }

        .controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            background: none;
            border: none;
            color: var(--text-primary);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.1s, opacity 0.2s;
            padding: 10px;
            border-radius: 50%;
            opacity: 0.8;
            filter: drop-shadow(0 2px 3px rgba(0,0,0,0.3));
        }

        .btn:hover { 
            opacity: 1;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .btn:active { transform: scale(0.9); }
        .btn svg { width: 22px; height: 22px; fill: currentColor; stroke: none; }

        .btn.active-state { 
            color: var(--accent); 
            opacity: 1;
        }

        .spotify-shuffle-btn {
            background: none;
            border: none;
            color: #b3b3b3;
            font-size: 18px;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            padding: 10px;
        }

        .spotify-shuffle-btn:hover { color: #ffffff; transform: scale(1.05); }
        .spotify-shuffle-btn.active-state { color: var(--accent); }
        .spotify-shuffle-btn.active-state::after {
            content: "";
            position: absolute;
            bottom: 2px;
            width: 4px;
            height: 4px;
            background-color: var(--accent);
            border-radius: 50%;
        }
        .spotify-shuffle-btn svg { width: 20px; height: 20px; fill: currentColor; }

        .play-btn {
            background-color: var(--text-primary);
            color: #121212;
            width: 64px;
            height: 64px;
            border-radius: 50%;
            padding: 0;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.1s, background-color 0.2s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.4);
        }

        .play-btn:hover { transform: scale(1.05); }
        .play-btn:active { transform: scale(0.95); }
        .play-btn svg { width: 28px; height: 28px; fill: currentColor; stroke: none; }
        .play-icon { transform: translateX(2px); }
        .pause-icon { display: none; }
        
        .playing .play-icon { display: none; }
        .playing .pause-icon { display: block; transform: none; }

        .repeat-wrapper { position: relative; }
        .repeat-one-dot {
            position: absolute;
            bottom: 2px;
            left: 50%;
            transform: translateX(-50%);
            width: 4px;
            height: 4px;
            background-color: var(--accent);
            border-radius: 50%;
            display: none;
        }

        .volume-wrapper {
            display: flex;
            align-items: center;
            gap: 15px;
            width: 100%;
            margin-top: 15px;
        }

        .vol-slider {
            -webkit-appearance: none;
            width: 100%;
            height: 5px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
            outline: none;
            cursor: pointer;
            position: relative;
            flex-grow: 1;
        }

        .vol-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: #ffffff;
            cursor: pointer;
            opacity: 1;
            box-shadow: 0 0 5px rgba(0,0,0,0.5);
            transition: transform 0.1s;
        }
        .vol-slider::-webkit-slider-thumb:active { transform: scale(1.3); }

        .vol-slider::-moz-range-thumb {
            width: 14px;
            height: 14px;
            border: none;
            border-radius: 50%;
            background: #ffffff;
            cursor: pointer;
            box-shadow: 0 0 5px rgba(0,0,0,0.5);
        }

        .volume-btn {
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 5px;
            transition: opacity 0.2s, transform 0.1s;
        }
        .volume-btn:hover { color: var(--text-primary); }
        .volume-btn:active { transform: scale(0.9); }
        .volume-btn svg { width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 2; }
        
        .vol-icon-on { display: block; }
        .vol-icon-off { display: none; }
        .muted .vol-icon-on { display: none; }
        .muted .vol-icon-off { display: block; }

        @media (min-width: 768px) {
            body { align-items: center; }
            .app-container { max-width: 900px; justify-content: center; }
            .player-content { flex-direction: row; align-items: center; gap: 60px; }
            .player-left { flex: 1; max-width: 450px; display: flex; justify-content: center; align-items: center; }
            .player-right { flex: 1.2; justify-content: center; }
            .art-container { width: 450px; height: 450px; margin-bottom: 0; }
            .info-section { align-items: flex-start; margin-bottom: 30px; }
            .title { text-align: left; font-size: 2.5rem; }
            .artist { text-align: left; font-size: 1.3rem; }
            .lyrics-toggle { margin-top: 15px; }
            .list-dropdown { max-height: 400px; }
            .volume-wrapper { margin-top: 25px; }
        }
    </style>
</head>
<body>

    <div class="bg-blur" id="bgBlur"></div>

    <div class="app-container">
        
        <div class="top-bar">
            <div class="search-container">
                <svg class="search-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <input type="text" id="searchInput" class="search-bar" placeholder="Find a song...">
            </div>
            
            <button id="playlistBtn" class="library-btn" title="Favorites Playlist">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                </svg>
            </button>

            <button id="libraryBtn" class="library-btn" title="View entire library">
                <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line>
                    <line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line>
                </svg>
            </button>

            <button id="settingsBtn" class="library-btn" title="Settings">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"></circle>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
            </button>

            <ul id="listDropdown" class="list-dropdown"></ul>
        </div>

        <div class="player-content">
            
            <div class="player-left">
                <div class="art-container" id="artContainer">
                    <img id="album-art" src="" alt="Album Art">
                    <div class="lyrics-container" id="lyricsBox">
                        Loading lyrics...
                    </div>
                    <button id="downloadBtn" title="Download for Offline">
                        <svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7 10 12 15 17 10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                    </button>
                    <button id="heartBtn" title="Add to Favorites">
                        <svg id="heartEmpty" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                        </svg>
                        <svg id="heartFilled" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                        </svg>
                    </button>
                </div>
            </div>

            <div class="player-right">
                <div class="info-section">
                    <div class="title" id="title">Loading Library...</div>
                    <div class="artist" id="artist">Please wait</div>
                    <button id="lyricsBtn" class="lyrics-toggle">Show Lyrics</button>
                </div>

                <div class="progress-wrapper">
                    <div class="visualizer-container" id="visContainer">
                        <canvas id="visCanvas" width="1000" height="100"></canvas>
                    </div>
                    <div class="time-labels">
                        <span id="currTime">0:00</span>
                        <span id="durTime">0:00</span>
                    </div>
                </div>

                <div class="controls">
                    <button class="spotify-shuffle-btn" id="shuffleBtn">
                        <svg viewBox="0 0 16 16"><path d="M13.151.922a.75.75 0 10-1.06 1.06L13.109 4H11.16a5.07 5.07 0 00-4.873 3.68c-.142.493-.306.845-.486 1.137-.202.329-.447.585-.806.761A3.947 3.947 0 013 10H.75a.75.75 0 000 1.5H3c.895 0 1.62-.26 2.21-.541.602-.288 1.05-.722 1.4-1.293.35-.572.584-1.23.754-1.815.163-.56.27-1.02.408-1.332.13-.298.24-.43.342-.505.101-.073.238-.134.453-.134h4.542l-1.018 1.018a.75.75 0 001.06 1.06L16.06 4.99a.75.75 0 000-1.06L13.15.922zm-4.32 8.358a.75.75 0 00-1.006-1.051c-.696.666-1.503 1.144-2.457 1.432C4.42 9.947 3.655 10 3 10H.75a.75.75 0 000 1.5H3c.758 0 1.62-.058 2.58-.337 1.066-.31 2.067-.852 2.92-1.637l.006-.006-.115-.098.25-.24z"></path><path d="M11.16 19.5H13.11l-1.018-1.018a.75.75 0 011.06-1.06l2.909 2.909a.75.75 0 010 1.06l-2.909 2.909a.75.75 0 11-1.06-1.06l1.018-1.018H11.16a5.07 5.07 0 01-4.873-3.68c-.142-.493-.306-.845-.486-1.137-.202-.329-.447-.585-.806-.761A3.947 3.947 0 003 13.5H.75a.75.75 0 010-1.5H3c.895 0 1.62.26 2.21.541.602.288 1.05.722 1.4 1.293.35.572.584 1.23.754 1.815.163.56.27 1.02.408 1.332.13.298.24.43.342.505.101.073.238.134.453.134h4.542z" transform="translate(0 -5)"></path></svg>
                    </button>
                    <button class="btn" id="prevBtn">
                        <svg viewBox="0 0 16 16"><path d="M3.3 1a.7.7 0 01.7.7v5.15l9.95-5.744a.7.7 0 011.05.606v12.575a.7.7 0 01-1.05.607L4 9.149V14.3a.7.7 0 01-.7.7H1.7a.7.7 0 01-.7-.7V1.7a.7.7 0 01.7-.7h1.6z"></path></svg>
                    </button>
                    <button class="play-btn" id="playBtn">
                        <svg class="play-icon" viewBox="0 0 24 24"><path d="M7.05 3.606l13.49 7.788a.7.7 0 010 1.212L7.05 20.394A.7.7 0 016 19.788V4.212a.7.7 0 011.05-.606z"></path></svg>
                        <svg class="pause-icon" viewBox="0 0 24 24"><path d="M5.7 3a.7.7 0 00-.7.7v16.6a.7.7 0 00.7.7h2.6a.7.7 0 00.7-.7V3.7a.7.7 0 00-.7-.7H5.7zm10 0a.7.7 0 00-.7.7v16.6a.7.7 0 00.7.7h2.6a.7.7 0 00.7-.7V3.7a.7.7 0 00-.7-.7h-2.6z"></path></svg>
                    </button>
                    <button class="btn" id="nextBtn">
                        <svg viewBox="0 0 16 16"><path d="M12.7 1a.7.7 0 00-.7.7v5.15L2.05 1.107A.7.7 0 001 1.712v12.575a.7.7 0 001.05.607L12 9.149V14.3a.7.7 0 00.7.7h1.6a.7.7 0 00.7-.7V1.7a.7.7 0 00-.7-.7h-1.6z"></path></svg>
                    </button>
                    <div class="repeat-wrapper">
                        <button class="btn" id="repeatBtn">
                            <svg viewBox="0 0 16 16"><path d="M0 4.75A3.75 3.75 0 013.75 1h8.5A3.75 3.75 0 0116 4.75v5a3.75 3.75 0 01-3.75 3.75H9.81l1.018 1.018a.75.75 0 11-1.06 1.06L6.939 12.75a.75.75 0 010-1.06l2.829-2.828a.75.75 0 111.06 1.06L9.811 11h2.439a2.25 2.25 0 002.25-2.25v-5a2.25 2.25 0 00-2.25-2.25h-8.5A2.25 2.25 0 001.5 4.75v5A2.25 2.25 0 003.75 12H5v1.5H3.75A3.75 3.75 0 010 9.75v-5z"></path></svg>
                        </button>
                        <div class="repeat-one-dot" id="repeatDot"></div>
                    </div>
                </div>

                <div class="volume-wrapper">
                    <button class="volume-btn" id="muteBtn" title="Mute/Unmute">
                        <svg class="vol-icon-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                            <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
                            <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                        </svg>
                        <svg class="vol-icon-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                            <line x1="23" y1="9" x2="17" y2="15"></line>
                            <line x1="17" y1="9" x2="23" y2="15"></line>
                        </svg>
                    </button>
                    <input type="range" class="vol-slider" id="volumeSlider" value="1" min="0" max="1" step="0.01">
                </div>

            </div>
        </div>

    </div>

    <div id="settingsModal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.6); z-index:9999; justify-content:center; align-items:center; backdrop-filter:blur(5px);">
        <div style="background:var(--bg-elevated); padding:25px; border-radius:15px; width:320px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);">
            <h2 style="margin-bottom:20px; text-align:center; font-size:1.4rem;">Server Settings</h2>
            
            <div style="margin-bottom:15px;">
                <label style="display:block; margin-bottom:8px; font-size:0.9rem; color:var(--text-secondary);">Binding (IP)</label>
                <input type="text" id="bindInput" style="width:100%; padding:10px 15px; border-radius:8px; border:1px solid rgba(255,255,255,0.2); background:rgba(0,0,0,0.3); color:white; outline:none; font-family:inherit;">
            </div>
            
            <div style="margin-bottom:15px;">
                <label style="display:block; margin-bottom:8px; font-size:0.9rem; color:var(--text-secondary);">Port</label>
                <input type="text" id="portInput" style="width:100%; padding:10px 15px; border-radius:8px; border:1px solid rgba(255,255,255,0.2); background:rgba(0,0,0,0.3); color:white; outline:none; font-family:inherit;">
            </div>

            <div style="margin-bottom:25px;">
                <label style="display:block; margin-bottom:8px; font-size:0.9rem; color:var(--text-secondary);">Music Directory</label>
                <input type="text" id="dirInput" style="width:100%; padding:10px 15px; border-radius:8px; border:1px solid rgba(255,255,255,0.2); background:rgba(0,0,0,0.3); color:white; outline:none; font-family:inherit;">
            </div>

            <div style="margin-bottom:25px; text-align:center;">
                <button id="rescanBtn" style="padding:8px 16px; border-radius:8px; border:1px solid rgba(255,255,255,0.2); background:rgba(255,255,255,0.05); color:white; cursor:pointer; font-weight:500; transition:0.2s; font-size:0.85rem;">⟳ Rescan Library</button>
                <div id="rescanMsg" style="margin-top:8px; font-size:0.8rem; color:var(--accent); display:none;">Rescanning...</div>
            </div>
            
            <div style="display:flex; justify-content:space-between; gap:10px;">
                <button id="closeSettings" style="flex:1; padding:10px; border-radius:8px; border:none; background:rgba(255,255,255,0.1); color:white; cursor:pointer; font-weight:600; transition:0.2s;">Cancel</button>
                <button id="saveSettings" style="flex:1; padding:10px; border-radius:8px; border:none; background:var(--accent); color:white; cursor:pointer; font-weight:600; transition:0.2s;">Save</button>
            </div>
            
            <div id="settingsMsg" style="margin-top:15px; text-align:center; font-size:0.85rem; color:#4caf50; display:none;">Settings saved! (Restart required for Port/IP changes)</div>
        </div>
    </div>

    <audio id="audio" crossorigin="anonymous"></audio>

    <script>
        // Initialize Service Worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/service-worker.js')
            .then(reg => console.log('Service Worker registered successfully'))
            .catch(err => console.error('Service Worker registration failed', err));
        }

        // Settings Logic
        const settingsBtn = document.getElementById('settingsBtn');
        const settingsModal = document.getElementById('settingsModal');
        const closeSettings = document.getElementById('closeSettings');
        const saveSettings = document.getElementById('saveSettings');
        const bindInput = document.getElementById('bindInput');
        const portInput = document.getElementById('portInput');
        const dirInput = document.getElementById('dirInput');
        const settingsMsg = document.getElementById('settingsMsg');
        const rescanBtn = document.getElementById('rescanBtn');
        const rescanMsg = document.getElementById('rescanMsg');

        settingsBtn.addEventListener('click', () => {
            fetch('/api/config')
                .then(res => res.json())
                .then(data => {
                    bindInput.value = data.binding;
                    portInput.value = data.port;
                    dirInput.value = data.music_dir;
                    settingsModal.style.display = 'flex';
                    settingsMsg.style.display = 'none';
                    rescanMsg.style.display = 'none';
                })
                .catch(err => console.error("Could not fetch config", err));
        });

        closeSettings.addEventListener('click', () => {
            settingsModal.style.display = 'none';
        });

        saveSettings.addEventListener('click', () => {
            const newConfig = {
                binding: bindInput.value,
                port: portInput.value,
                music_dir: dirInput.value
            };
            fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newConfig)
            }).then(res => {
                if(res.ok) {
                    settingsMsg.style.display = 'block';
                    loadMusic(); 
                    setTimeout(() => { settingsModal.style.display = 'none'; }, 2500);
                }
            });
        });

        rescanBtn.addEventListener('click', () => {
            rescanMsg.style.display = 'block';
            rescanMsg.innerText = 'Rescanning...';
            rescanMsg.style.color = 'var(--text-secondary)';
            fetch('/api/rescan').then(() => {
                rescanMsg.innerText = 'Scan Complete! Library Updated.';
                rescanMsg.style.color = '#4caf50';
                loadMusic();
                setTimeout(() => rescanMsg.style.display = 'none', 3000);
            }).catch(() => {
                rescanMsg.innerText = 'Error rescanning.';
                rescanMsg.style.color = '#f44336';
            });
        });

        const audio = document.getElementById('audio');
        const playBtn = document.getElementById('playBtn');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const shuffleBtn = document.getElementById('shuffleBtn');
        const repeatBtn = document.getElementById('repeatBtn');
        const repeatDot = document.getElementById('repeatDot');
        
        const titleEl = document.getElementById('title');
        const artistEl = document.getElementById('artist');
        const artContainer = document.getElementById('artContainer');
        const albumArt = document.getElementById('album-art');
        const bgBlur = document.getElementById('bgBlur');
        const currTimeEl = document.getElementById('currTime');
        const durTimeEl = document.getElementById('durTime');
        
        const searchInput = document.getElementById('searchInput');
        const libraryBtn = document.getElementById('libraryBtn');
        const playlistBtn = document.getElementById('playlistBtn');
        const listDropdown = document.getElementById('listDropdown');
        
        const lyricsBtn = document.getElementById('lyricsBtn');
        const lyricsBox = document.getElementById('lyricsBox');
        const heartBtn = document.getElementById('heartBtn');
        const downloadBtn = document.getElementById('downloadBtn');

        const volumeSlider = document.getElementById('volumeSlider');
        const muteBtn = document.getElementById('muteBtn');

        // VISUALIZER ELEMENTS
        const visContainer = document.getElementById('visContainer');
        const visCanvas = document.getElementById('visCanvas');
        const canvasCtx = visCanvas.getContext('2d');
        
        let audioCtx, analyser, source, dataArray, bufferLength;
        let isAudioInit = false;

        let songs = [];
        let favorites = [];
        let currentQueue = [];
        let currentIndex = 0;
        let isPlaying = false;
        let isShuffle = false;
        let repeatMode = 0; 
        let currentListMode = ''; 

        // Update the OS lock screen progress bar
        function updatePositionState() {
            if ('mediaSession' in navigator && !isNaN(audio.duration) && audio.duration > 0) {
                try {
                    navigator.mediaSession.setPositionState({
                        duration: audio.duration,
                        playbackRate: audio.playbackRate || 1,
                        position: audio.currentTime
                    });
                } catch (e) {}
            }
        }

        if ('mediaSession' in navigator) {
            navigator.mediaSession.setActionHandler('play', playAudio);
            navigator.mediaSession.setActionHandler('pause', pauseAudio);
            navigator.mediaSession.setActionHandler('previoustrack', prevSong);
            navigator.mediaSession.setActionHandler('nexttrack', nextSong);
            
            navigator.mediaSession.setActionHandler('seekbackward', (details) => {
                const skipTime = details.seekOffset || 10;
                audio.currentTime = Math.max(audio.currentTime - skipTime, 0);
                updatePositionState();
            });

            navigator.mediaSession.setActionHandler('seekforward', (details) => {
                const skipTime = details.seekOffset || 10;
                audio.currentTime = Math.min(audio.currentTime + skipTime, audio.duration);
                updatePositionState();
            });

            navigator.mediaSession.setActionHandler('seekto', (details) => {
                if (details.fastSeek && 'fastSeek' in audio) {
                    audio.fastSeek(details.seekTime);
                } else {
                    audio.currentTime = details.seekTime;
                }
                updatePositionState();
            });
        }

        audio.addEventListener('loadedmetadata', updatePositionState);
        audio.addEventListener('play', updatePositionState);
        audio.addEventListener('pause', updatePositionState);

        let savedVolume = localStorage.getItem('neoVolume');
        if (savedVolume !== null) {
            savedVolume = parseFloat(savedVolume);
            audio.volume = savedVolume;
            volumeSlider.value = savedVolume;
        } else {
            audio.volume = 1;
            volumeSlider.value = 1;
        }
        updateVolumeUI(volumeSlider.value);

        function updateVolumeUI(val) {
            const percent = val * 100;
            volumeSlider.style.background = "linear-gradient(to right, #ffffff " + percent + "%, rgba(255,255,255,0.3) " + percent + "%)";
            if (val == 0 || audio.muted) muteBtn.classList.add('muted');
            else muteBtn.classList.remove('muted');
        }

        volumeSlider.addEventListener('input', (e) => {
            const val = e.target.value;
            audio.volume = val;
            audio.muted = false;
            updateVolumeUI(val);
            localStorage.setItem('neoVolume', val);
        });

        muteBtn.addEventListener('click', () => {
            audio.muted = !audio.muted;
            if (audio.muted) updateVolumeUI(0);
            else {
                updateVolumeUI(audio.volume);
                if(audio.volume == 0) {
                    audio.volume = 0.5;
                    volumeSlider.value = 0.5;
                    updateVolumeUI(0.5);
                    localStorage.setItem('neoVolume', 0.5);
                }
            }
        });

        function initAudioVisualizer() {
            if (isAudioInit) return;
            isAudioInit = true;
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            analyser = audioCtx.createAnalyser();
            analyser.fftSize = 128;
            bufferLength = analyser.frequencyBinCount;
            dataArray = new Uint8Array(bufferLength);
            source = audioCtx.createMediaElementSource(audio);
            source.connect(analyser);
            analyser.connect(audioCtx.destination);
            drawVisualizer();
        }

        function drawVisualizer() {
            requestAnimationFrame(drawVisualizer);
            if (isAudioInit) analyser.getByteFrequencyData(dataArray);
            canvasCtx.clearRect(0, 0, visCanvas.width, visCanvas.height);
            
            const bars = bufferLength || 64; 
            const barWidth = visCanvas.width / bars;
            const progressRatio = audio.duration ? (audio.currentTime / audio.duration) : 0;
            const progressX = progressRatio * visCanvas.width;

            for(let i = 0; i < bars; i++) {
                let freqVal = dataArray ? dataArray[i] : 0;
                let barHeight = (freqVal / 255) * visCanvas.height * 0.8; 
                if (barHeight < 6) barHeight = 6; 
                const x = i * barWidth;
                const y = (visCanvas.height - barHeight) / 2;

                if (x + (barWidth / 2) < progressX) {
                    canvasCtx.fillStyle = '#2979ff';
                } else {
                    canvasCtx.fillStyle = 'rgba(255, 255, 255, 0.3)';
                }
                canvasCtx.beginPath();
                canvasCtx.roundRect(x + 2, y, barWidth - 4, barHeight, 4);
                canvasCtx.fill();
            }
        }
        drawVisualizer();

        let isDraggingVis = false;
        function handleSeek(e) {
            if (!audio.duration) return;
            const rect = visContainer.getBoundingClientRect();
            let clientX = e.touches ? e.touches[0].clientX : e.clientX;
            let clickX = clientX - rect.left;
            if (clickX < 0) clickX = 0;
            if (clickX > rect.width) clickX = rect.width;
            
            const percent = clickX / rect.width;
            audio.currentTime = percent * audio.duration;
            updatePositionState();
        }

        visContainer.addEventListener('mousedown', (e) => { isDraggingVis = true; handleSeek(e); });
        visContainer.addEventListener('touchstart', (e) => { isDraggingVis = true; handleSeek(e); });
        window.addEventListener('mouseup', () => isDraggingVis = false);
        window.addEventListener('touchend', () => isDraggingVis = false);
        window.addEventListener('mousemove', (e) => { if (isDraggingVis) handleSeek(e); });
        window.addEventListener('touchmove', (e) => { if (isDraggingVis) handleSeek(e); });

        async function loadMusic() {
            try {
                const res = await fetch('/api/songs');
                songs = await res.json();
                
                const favRes = await fetch('/api/favorites');
                favorites = await favRes.json() || [];

                if (songs && songs.length > 0) {
                    if (currentQueue.length === 0) currentQueue = [...songs];
                    
                    if (!audio.src || !isPlaying) loadSong(currentQueue[currentIndex]);
                    else if (listDropdown.style.display === 'block') {
                        if (currentListMode === 'library') renderList(songs);
                        else if (currentListMode === 'playlist') renderList(songs.filter(s => favorites.includes(s.id)));
                    }
                } else {
                    titleEl.innerText = "No music found";
                    artistEl.innerText = "Library is empty";
                    lyricsBox.innerText = "";
                    albumArt.style.display = 'none';
                    bgBlur.style.backgroundImage = 'none';
                }
            } catch (err) {
                titleEl.innerText = "Offline Mode";
                artistEl.innerText = "Check your downloaded songs";
            }
        }

        async function checkDownloadedStatus(song) {
            if (!('caches' in window)) return;
            const cache = await caches.open('neomusic-v1');
            const res = await cache.match(song.audio_url);
            if (res) downloadBtn.classList.add('downloaded');
            else downloadBtn.classList.remove('downloaded');
        }

        function loadSong(song) {
            if (!song) return;
            titleEl.innerText = song.title;
            artistEl.innerText = song.artist;
            audio.src = song.audio_url;

            if (favorites.includes(song.id)) heartBtn.classList.add('heart-active');
            else heartBtn.classList.remove('heart-active');

            checkDownloadedStatus(song);

            if (song.art_url) {
                albumArt.src = song.art_url;
                albumArt.style.display = 'block';
                bgBlur.style.backgroundImage = 'url(' + song.art_url + ')';
            } else {
                albumArt.src = '';
                albumArt.style.display = 'none';
                bgBlur.style.backgroundImage = 'none';
            }

            if ('mediaSession' in navigator) {
                navigator.mediaSession.metadata = new MediaMetadata({
                    title: song.title,
                    artist: song.artist,
                    album: song.album || 'Unknown Album',
                    artwork: [
                        { src: song.art_url || '/icon.png', sizes: '512x512', type: 'image/png' }
                    ]
                });
            }

            if (song.lyrics && song.lyrics.trim() !== "") lyricsBox.innerHTML = song.lyrics.replace(/\n/g, '<br>');
            else lyricsBox.innerHTML = "<em>No lyrics available</em>";
            lyricsBox.scrollTop = 0;
            
            if (listDropdown.style.display === 'block') {
                if (currentListMode === 'library') renderList(songs);
                else if (currentListMode === 'playlist') renderList(songs.filter(s => favorites.includes(s.id)));
                else if (currentListMode === 'search') triggerSearch(searchInput.value);
            }
        }

        downloadBtn.addEventListener('click', async () => {
            const song = currentQueue[currentIndex];
            if (!song || !('caches' in window)) return;
            
            const cache = await caches.open('neomusic-v1');
            const isDownloaded = downloadBtn.classList.contains('downloaded');

            if (isDownloaded) {
                await cache.delete(song.audio_url);
                if (song.art_url) await cache.delete(song.art_url);
                downloadBtn.classList.remove('downloaded');
            } else {
                try {
                    await cache.add(song.audio_url);
                    if (song.art_url) await cache.add(song.art_url);
                    downloadBtn.classList.add('downloaded');
                } catch (e) {
                    console.error("Failed to cache offline media", e);
                }
            }
        });

        heartBtn.addEventListener('click', () => {
            const song = currentQueue[currentIndex];
            if (!song) return;

            if (favorites.includes(song.id)) {
                favorites = favorites.filter(id => id !== song.id);
                heartBtn.classList.remove('heart-active');
            } else {
                favorites.push(song.id);
                heartBtn.classList.add('heart-active');
            }

            fetch('/api/favorites', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(favorites)
            });

            if (currentListMode === 'playlist' && listDropdown.style.display === 'block') {
                const favSongs = songs.filter(s => favorites.includes(s.id));
                if (favSongs.length === 0) listDropdown.innerHTML = '<li style="text-align:center; padding:20px;">No favorites yet</li>';
                else renderList(favSongs);
            }
        });

        function playAudio() {
            initAudioVisualizer();
            if (audioCtx && audioCtx.state === 'suspended') {
                audioCtx.resume();
            }
            audio.play().catch(e => console.log("Playback interrupted"));
            playBtn.classList.add('playing');
            isPlaying = true;
        }

        function pauseAudio() {
            audio.pause();
            playBtn.classList.remove('playing');
            isPlaying = false;
        }

        function togglePlay() {
            if (isPlaying) pauseAudio();
            else playAudio();
        }

        function prevSong() {
            if (audio.currentTime > 3) {
                audio.currentTime = 0;
                return;
            }
            currentIndex--;
            if (currentIndex < 0) currentIndex = currentQueue.length - 1;
            loadSong(currentQueue[currentIndex]);
            if (isPlaying) playAudio();
        }

        function nextSong() {
            currentIndex++;
            if (currentIndex > currentQueue.length - 1) {
                if (repeatMode === 1) currentIndex = 0;
                else {
                    currentIndex = currentQueue.length - 1;
                    if (isPlaying) togglePlay();
                    return;
                }
            }
            loadSong(currentQueue[currentIndex]);
            if (isPlaying) playAudio();
        }

        lyricsBtn.addEventListener('click', () => {
            artContainer.classList.toggle('show-lyrics');
            if (artContainer.classList.contains('show-lyrics')) {
                lyricsBtn.innerText = 'Hide Lyrics';
                lyricsBtn.classList.add('active');
            } else {
                lyricsBtn.innerText = 'Show Lyrics';
                lyricsBtn.classList.remove('active');
            }
        });

        playBtn.addEventListener('click', togglePlay);
        prevBtn.addEventListener('click', prevSong);
        nextBtn.addEventListener('click', nextSong);

        // FIX: Handle Native Audio Looping for "Repeat One" to avoid ended event bugs
        repeatBtn.addEventListener('click', () => {
            repeatMode = (repeatMode + 1) % 3;
            if (repeatMode === 0) {
                repeatBtn.classList.remove('active-state');
                repeatDot.style.display = 'none';
                audio.loop = false; // Turn off native loop
            } else if (repeatMode === 1) {
                repeatBtn.classList.add('active-state');
                repeatDot.style.display = 'none';
                audio.loop = false; // Turn off native loop (repeats entire list, not one song)
            } else if (repeatMode === 2) {
                repeatBtn.classList.add('active-state');
                repeatDot.style.display = 'block';
                audio.loop = true; // Turn ON native loop for seamless single-track repeating
            }
        });

        shuffleBtn.addEventListener('click', () => {
            isShuffle = !isShuffle;
            let currentSong = currentQueue[currentIndex];
            if (isShuffle) {
                shuffleBtn.classList.add('active-state');
                currentQueue = [...currentQueue].sort(() => Math.random() - 0.5);
            } else {
                shuffleBtn.classList.remove('active-state');
                if (currentListMode === 'playlist') currentQueue = songs.filter(s => favorites.includes(s.id));
                else currentQueue = [...songs];
            }
            currentIndex = currentQueue.findIndex(s => s.id === currentSong.id);
        });

        audio.addEventListener('timeupdate', () => {
            if (!audio.duration) return;

            let currMins = Math.floor(audio.currentTime / 60);
            let currSecs = Math.floor(audio.currentTime % 60);
            currTimeEl.innerText = currMins + ":" + (currSecs < 10 ? '0' : '') + currSecs;

            let durMins = Math.floor(audio.duration / 60);
            let durSecs = Math.floor(audio.duration % 60);
            durTimeEl.innerText = durMins + ":" + (durSecs < 10 ? '0' : '') + durSecs;
        });

        // FIX: Only trigger nextSong if we are not natively looping the current track
        audio.addEventListener('ended', () => {
            if (repeatMode !== 2) {
                nextSong();
            }
        });

        function renderList(listToRender) {
            listDropdown.innerHTML = '';
            if (listToRender.length === 0) {
                listDropdown.style.display = 'none';
                return;
            }

            const activeSongId = currentQueue[currentIndex] ? currentQueue[currentIndex].id : null;

            listToRender.forEach(song => {
                const li = document.createElement('li');
                if (song.id === activeSongId) li.classList.add('active-song');
                li.innerHTML = '<span class="res-title">' + song.title + '</span><span class="res-artist">' + song.artist + '</span>';
                
                li.addEventListener('click', () => {
                    if (currentListMode === 'search') currentQueue = [...songs];
                    else currentQueue = [...listToRender];
                    
                    if (isShuffle) currentQueue = [...currentQueue].sort(() => Math.random() - 0.5);

                    currentIndex = currentQueue.findIndex(q => q.id === song.id);
                    if (currentIndex === -1) currentIndex = 0;

                    loadSong(currentQueue[currentIndex]);
                    playAudio();
                    searchInput.value = '';
                    listDropdown.style.display = 'none';
                });
                listDropdown.appendChild(li);
            });
            listDropdown.style.display = 'block';
        }

        playlistBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (listDropdown.style.display === 'block' && currentListMode === 'playlist') {
                listDropdown.style.display = 'none';
                currentListMode = '';
                playlistBtn.classList.remove('playlist-active');
            } else {
                searchInput.value = '';
                currentListMode = 'playlist';
                playlistBtn.classList.add('playlist-active');
                libraryBtn.classList.remove('playlist-active');
                
                const favSongs = songs.filter(s => favorites.includes(s.id));
                if (favSongs.length === 0) {
                    listDropdown.innerHTML = '<li style="text-align:center; padding:20px;">No favorites yet</li>';
                    listDropdown.style.display = 'block';
                } else renderList(favSongs);
            }
        });

        libraryBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (listDropdown.style.display === 'block' && currentListMode === 'library') {
                listDropdown.style.display = 'none';
                currentListMode = '';
                libraryBtn.classList.remove('playlist-active');
            } else {
                searchInput.value = '';
                currentListMode = 'library';
                libraryBtn.classList.add('playlist-active');
                playlistBtn.classList.remove('playlist-active');
                renderList(songs);
            }
        });

        function triggerSearch(term) {
            term = term.toLowerCase().trim();
            if (!term) {
                listDropdown.style.display = 'none';
                return;
            }
            const filtered = songs.filter(s => 
                s.title.toLowerCase().includes(term) || 
                s.artist.toLowerCase().includes(term)
            );
            renderList(filtered);
        }

        searchInput.addEventListener('input', (e) => {
            currentListMode = 'search';
            playlistBtn.classList.remove('playlist-active');
            libraryBtn.classList.remove('playlist-active');
            triggerSearch(e.target.value);
        });

        document.addEventListener('click', (e) => {
            if (!e.target.closest('.top-bar') && !e.target.closest('#settingsModal')) {
                listDropdown.style.display = 'none';
                playlistBtn.classList.remove('playlist-active');
                libraryBtn.classList.remove('playlist-active');
            }
        });

        loadMusic();
    </script>
</body>
</html>`)
